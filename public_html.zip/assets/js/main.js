
// Mobile nav
const toggle = document.querySelector('.nav-toggle');
const menu = document.querySelector('nav.primary');
if(toggle){
  toggle.addEventListener('click', ()=> menu.classList.toggle('open'));
}

// Simple client-side validation for contact form
const form = document.querySelector('#contact-form');
if(form){
  form.addEventListener('submit', (e)=>{
    const required = form.querySelectorAll('[required]');
    let ok = true;
    required.forEach(i=>{
      if(!i.value.trim()){ ok=false; i.classList.add('err'); }
      else i.classList.remove('err');
    });
    if(!ok){
      e.preventDefault();
      alert('Please fill in all required fields.');
    }
  });
}
