(function(){
  function closeAll(except){
    document.querySelectorAll('nav.primary .dropdown.open').forEach(function(dd){
      if(except && dd===except) return;
      dd.classList.remove('open');
      var trigger = dd.querySelector(':scope > a');
      if(trigger){ trigger.setAttribute('aria-expanded','false'); }
    });
  }

  function init(){
    var nav = document.querySelector('nav.primary');
    if(!nav) return;
    nav.querySelectorAll('.dropdown > a').forEach(function(trigger, idx){
      trigger.setAttribute('role','button');
      trigger.setAttribute('aria-haspopup','true');
      if(!trigger.hasAttribute('aria-expanded')) trigger.setAttribute('aria-expanded','false');
      trigger.addEventListener('click', function(e){
        e.preventDefault();
        var dd = trigger.closest('.dropdown');
        var isOpen = dd.classList.contains('open');
        closeAll();
        if(!isOpen){
          dd.classList.add('open');
          trigger.setAttribute('aria-expanded','true');
        }
      });
      trigger.addEventListener('keydown', function(e){
        if(e.key === 'ArrowDown'){
          e.preventDefault();
          var first = trigger.parentElement.querySelector('.dropdown-content a');
          if(first) first.focus();
        }
      });
    });

    document.addEventListener('click', function(e){
      var within = e.target.closest('nav.primary .dropdown');
      if(!within){ closeAll(); }
    });

    document.addEventListener('keydown', function(e){
      if(e.key === 'Escape'){ closeAll(); }
    });
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', init);
  }else{ init(); }
})();