Replace the placeholder images with actual photos from https://www.facebook.com/fpcsda
Name them hero1.jpg, hero2.jpg, hero3.jpg, hero4.jpg, pastor.jpg, p1.jpg ... p15.jpg
Recommended sizes: 1600x1067 (hero), 600x600 (portraits).